import { useState, useEffect, useCallback } from "react";
import { io, Socket } from "socket.io-client";

export type ConnectionState =
  | "disconnected"
  | "connecting"
  | "connected"
  | "error";

export interface FileData {
  name: string;
  size: number;
  type: string;
  data: ArrayBuffer;
}

// In production, this will use the explicitly defined environment variable.
// In development, it defaults to localhost:3001.
const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || "http://localhost:3001";

export function useSocketSharing() {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [roomId, setRoomId] = useState<string>("");
  const [status, setStatus] = useState<ConnectionState>("disconnected");
  const [receivedFiles, setReceivedFiles] = useState<FileData[]>([]);
  const [errorText, setErrorText] = useState<string>("");

  useEffect(() => {
    // Initialize socket connection to the relay server
    const newSocket = io(SOCKET_URL, {
      reconnection: true,
      reconnectionAttempts: 10,
      reconnectionDelay: 1000,
    });

    newSocket.on("connect", () => {
      console.log("Connected to private signaling server", newSocket.id);
    });

    newSocket.on("connect_error", (err) => {
      setErrorText(`Server connection failed: ${err.message}`);
      setStatus("error");
    });

    setSocket(newSocket);

    // Cleanup on unmount
    return () => {
      newSocket.disconnect();
    };
  }, []);

  const initRoom = useCallback(() => {
    if (!socket) return "";
    setStatus("connecting");
    setErrorText("");

    // Generate our beautiful agency short code
    const generatedCode = Math.random()
      .toString(36)
      .substring(2, 8)
      .toUpperCase();

    socket.emit("create-room", generatedCode);

    // Server confirms room created
    socket.once("room-created", (id) => {
      setRoomId(id);
      setStatus("disconnected"); // Room exists, waiting for peer
    });

    return generatedCode;
  }, [socket]);

  const joinRoom = useCallback(
    (targetId: string) => {
      if (!socket) return;
      setStatus("connecting");
      setErrorText("");
      setRoomId(targetId);

      socket.emit("join-room", targetId);
    },
    [socket],
  );

  // Setup main event listeners whenever socket or roomId changes
  useEffect(() => {
    if (!socket || !roomId) return;

    const onPeerConnected = () => {
      setStatus("connected");
      setErrorText("");
    };

    const onError = (msg: string) => {
      setErrorText(msg);
      setStatus("error");
    };

    const onFileReceived = (file: FileData) => {
      setReceivedFiles((prev) => [...prev, file]);
    };

    const onPeerDisconnected = () => {
      console.log("Peer disconnected. Shredding room data...");
      // Auto-shred the room state because the other person left
      setErrorText("Peer disconnected. Room destroyed.");
      setStatus("disconnected");
      setRoomId("");
      setReceivedFiles([]);
      // Sever the socket connection for full security since room is gone
      if (socket) {
        socket.disconnect();
      }
    };

    socket.on("peer-connected", onPeerConnected);
    socket.on("error", onError);
    socket.on("file-received", onFileReceived);
    socket.on("peer-disconnected", onPeerDisconnected);

    return () => {
      socket.off("peer-connected", onPeerConnected);
      socket.off("error", onError);
      socket.off("file-received", onFileReceived);
      socket.off("peer-disconnected", onPeerDisconnected);
    };
  }, [socket, roomId]);

  const sendFile = useCallback(
    async (file: File) => {
      if (!socket || status !== "connected" || !roomId) return;

      const arrayBuffer = await file.arrayBuffer();

      const fileData: FileData = {
        name: file.name,
        size: file.size,
        type: file.type,
        data: arrayBuffer,
      };

      socket.emit("file-chunk", { roomId, file: fileData });
    },
    [socket, status, roomId],
  );

  const closeRoom = useCallback(() => {
    if (socket && roomId) {
      socket.emit("close-room", roomId);
    }
    setRoomId("");
    setStatus("disconnected");
    setReceivedFiles([]);
    setErrorText("");
  }, [socket, roomId]);

  return {
    peerId: roomId,
    status,
    receivedFiles,
    errorText,
    initPeer: initRoom, // Keep alias same for React components
    connectToPeer: joinRoom, // Keep alias same for React components
    sendFile,
    closeRoom,
  };
}
