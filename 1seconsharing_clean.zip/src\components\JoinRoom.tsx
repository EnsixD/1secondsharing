import React, { useState } from "react";
import { motion } from "framer-motion";
import { Link2, ArrowLeft, ArrowRight, Loader2 } from "lucide-react";
import type { ConnectionState } from "../hooks/useSocketSharing";

interface JoinRoomProps {
  onBack: () => void;
  connectToPeer: (id: string) => void;
  status: ConnectionState;
  errorText: string;
}

export const JoinRoom: React.FC<JoinRoomProps> = ({
  onBack,
  connectToPeer,
  status,
  errorText,
}) => {
  const [targetId, setTargetId] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (targetId.trim()) {
      connectToPeer(targetId.trim());
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -50 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 50 }}
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        minHeight: "100vh",
        padding: "2rem",
      }}
    >
      <button
        onClick={onBack}
        style={{
          position: "absolute",
          top: "2rem",
          left: "2rem",
          background: "transparent",
          border: "none",
          color: "var(--color-text-secondary)",
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          gap: "8px",
        }}
      >
        <ArrowLeft size={20} /> Back
      </button>

      <div
        className="glass-card"
        style={{
          padding: "3rem",
          maxWidth: "500px",
          width: "100%",
          textAlign: "center",
        }}
      >
        <Link2
          className="text-gradient"
          size={48}
          style={{ margin: "0 auto 24px auto" }}
        />
        <h2 style={{ fontSize: "2rem", marginBottom: "8px" }}>Join Room</h2>
        <p style={{ marginBottom: "32px" }}>
          Enter the unique code provided to you to establish a secure P2P
          connection.
        </p>

        {errorText && (
          <div
            style={{
              padding: "16px",
              background: "var(--color-danger-glow)",
              border: "1px solid var(--color-danger)",
              borderRadius: "12px",
              color: "var(--color-danger)",
              marginBottom: "24px",
            }}
          >
            {errorText}
          </div>
        )}

        <form
          onSubmit={handleSubmit}
          style={{ display: "flex", flexDirection: "column", gap: "24px" }}
        >
          <input
            type="text"
            className="glass-input"
            placeholder="Room Code (e.g. A1B2C3D)"
            value={targetId}
            onChange={(e) => setTargetId(e.target.value.toUpperCase())}
            style={{
              textAlign: "center",
              fontSize: "1.5rem",
              letterSpacing: "2px",
              padding: "20px",
            }}
            disabled={status === "connecting"}
            required
          />
          <button
            type="submit"
            className="glass-button primary"
            style={{
              padding: "20px",
              fontSize: "1.2rem",
              display: "flex",
              justifyContent: "center",
            }}
            disabled={status === "connecting" || !targetId.trim()}
          >
            {status === "connecting" ? (
              <Loader2
                className="lucide-spin text-gradient"
                size={24}
                style={{ animation: "spin 2s linear infinite" }}
              />
            ) : (
              <>
                <span>Connect Securely</span>
                <ArrowRight size={20} />
              </>
            )}
          </button>
        </form>
      </div>
      <style>{`@keyframes spin { 100% { transform: rotate(360deg); } }`}</style>
    </motion.div>
  );
};
