import { useState, useEffect } from "react";
import { AnimatePresence } from "framer-motion";
import { Home } from "./components/Home";
import { CreateRoom } from "./components/CreateRoom";
import { JoinRoom } from "./components/JoinRoom";
import { ActiveRoom } from "./components/ActiveRoom";
import { useSocketSharing } from "./hooks/useSocketSharing";
import "./index.css";

type View = "home" | "create" | "join" | "active";

function App() {
  const [view, setView] = useState<View>("home");
  const {
    peerId,
    status,
    receivedFiles,
    errorText,
    initPeer,
    connectToPeer,
    sendFile,
    closeRoom,
  } = useSocketSharing();

  // Handle transitions based on status
  useEffect(() => {
    if (status === "connected") {
      setView("active");
    } else if (status === "disconnected" && view === "active") {
      // If we were active and got disconnected (peer closed room), instantly shred view
      setView("home");
    }
  }, [status, view]);

  const handleBack = () => {
    closeRoom();
    setView("home");
  };

  const handleCloseRoom = () => {
    closeRoom();
    setView("home");
  };

  return (
    <>
      {/* Background elements */}
      <div
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          width: "100vw",
          height: "100vh",
          zIndex: -1,
          pointerEvents: "none",
        }}
      >
        <div
          style={{
            position: "absolute",
            top: "10%",
            left: "10%",
            width: "40vw",
            height: "40vw",
            background:
              "radial-gradient(circle, rgba(59, 130, 246, 0.05) 0%, transparent 70%)",
            borderRadius: "50%",
            filter: "blur(60px)",
          }}
        />
        <div
          style={{
            position: "absolute",
            bottom: "10%",
            right: "10%",
            width: "30vw",
            height: "30vw",
            background:
              "radial-gradient(circle, rgba(139, 92, 246, 0.05) 0%, transparent 70%)",
            borderRadius: "50%",
            filter: "blur(60px)",
          }}
        />
      </div>

      <header
        style={{
          display: "flex",
          justifyContent: "center", // Centered content
          alignItems: "center",
          padding: "20px 40px",
          borderBottom: "1px solid rgba(255,255,255,0.05)",
          background: "rgba(10, 10, 10, 0.4)",
          backdropFilter: "blur(20px)",
          position: "sticky",
          top: 0,
          zIndex: 50,
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "12px",
            cursor: "pointer",
          }}
          onClick={() => {
            if (status !== "connected") setView("home");
          }}
        >
          <div
            style={{
              background:
                "linear-gradient(135deg, var(--color-accent-blue), var(--color-accent-purple))",
              padding: "8px",
              borderRadius: "12px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: "0 0 15px var(--color-accent-glow)",
            }}
          >
            <svg
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="white"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              {/* Hand 1 (Left, giving) */}
              <path d="M4 14h6l3-3" />
              <path d="M4 14c-1.1 0-2-.9-2-2V7c0-1.1.9-2 2-2h3" />

              {/* Hand 2 (Right, receiving) */}
              <path d="M20 10h-6l-3 3" />
              <path d="M20 10c1.1 0 2 .9 2 2v5c0 1.1-.9 2-2 2h-3" />

              {/* Glowing shared object in middle */}
              <circle cx="12" cy="12" r="2" fill="white" />
            </svg>
          </div>
          <h1
            style={{
              fontSize: "1.5rem", // Slightly larger and prouder
              fontWeight: 700,
              letterSpacing: "-0.5px",
              background: "linear-gradient(to right, #fff, #a0a0a0)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            1SecondSharing
          </h1>
        </div>
      </header>

      <main style={{ flex: 1, position: "relative", overflow: "hidden" }}>
        <AnimatePresence mode="wait">
          {view === "home" && (
            <Home
              key="home"
              onCreateRoom={() => setView("create")}
              onJoinRoom={() => setView("join")}
            />
          )}
          {view === "create" && (
            <CreateRoom
              key="create"
              onBack={handleBack}
              initPeer={initPeer}
              peerId={peerId}
              status={status}
              errorText={errorText}
            />
          )}
          {view === "join" && (
            <JoinRoom
              key="join"
              onBack={handleBack}
              connectToPeer={connectToPeer}
              status={status}
              errorText={errorText}
            />
          )}
          {view === "active" && (
            <ActiveRoom
              key="active"
              peerId={peerId}
              receivedFiles={receivedFiles}
              sendFile={sendFile}
              closeRoom={handleCloseRoom}
            />
          )}
        </AnimatePresence>
      </main>

      <footer
        style={{
          padding: "2rem",
          textAlign: "center",
          color: "var(--color-text-secondary)",
          borderTop: "1px solid var(--color-surface-border)",
          background: "rgba(5, 5, 5, 0.8)",
        }}
      >
        <p style={{ fontSize: "0.85rem" }}>
          © {new Date().getFullYear()} 1SecondSharing. For High-End Agencies.
        </p>
        <p style={{ fontSize: "0.75rem", opacity: 0.5, marginTop: "8px" }}>
          P2P WebRTC Tech • Zero Server Storage
        </p>
      </footer>
    </>
  );
}

export default App;
