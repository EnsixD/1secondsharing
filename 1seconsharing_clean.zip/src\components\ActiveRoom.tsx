import React, { useCallback, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  UploadCloud,
  File,
  Trash2,
  ShieldCheck,
  Download,
  Activity,
} from "lucide-react";
import type { FileData } from "../hooks/useSocketSharing";

interface ActiveRoomProps {
  peerId: string;
  receivedFiles: FileData[];
  sendFile: (file: globalThis.File) => void;
  closeRoom: () => void;
}

export const ActiveRoom: React.FC<ActiveRoomProps> = ({
  peerId,
  receivedFiles,
  sendFile,
  closeRoom,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [sentFiles, setSentFiles] = useState<{ name: string; size: number }[]>(
    [],
  );

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);

      if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        const filesArray = Array.from(e.dataTransfer.files);
        filesArray.forEach((file) => {
          sendFile(file);
          setSentFiles((prev) => [
            ...prev,
            { name: file.name, size: file.size },
          ]);
        });
      }
    },
    [sendFile],
  );

  const handleFileInput = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files.length > 0) {
        const filesArray = Array.from(e.target.files);
        filesArray.forEach((file) => {
          sendFile(file);
          setSentFiles((prev) => [
            ...prev,
            { name: file.name, size: file.size },
          ]);
        });
      }
    },
    [sendFile],
  );

  const downloadFile = (fileData: FileData) => {
    const blob = new window.Blob([fileData.data], { type: fileData.type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = fileData.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      style={{
        display: "flex",
        flexDirection: "column",
        minHeight: "100vh",
        padding: "2rem",
        maxWidth: "1200px",
        margin: "0 auto",
      }}
    >
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, type: "spring" }}
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: "40px",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
          <div
            style={{
              padding: "12px",
              background: "var(--color-surface-2)",
              borderRadius: "16px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              animation: "glow-pulse 4s infinite", // neon pulsing
            }}
          >
            <Activity className="text-gradient-accent" size={24} />
          </div>
          <div>
            <h2
              style={{
                fontSize: "1.5rem",
                fontWeight: 600,
                display: "flex",
                alignItems: "center",
                gap: "8px",
              }}
            >
              Secure Connection Active
              <ShieldCheck color="var(--color-success)" size={20} />
            </h2>
            <p
              style={{
                color: "var(--color-text-secondary)",
                fontSize: "0.9rem",
              }}
            >
              Room ID:{" "}
              <span
                style={{
                  color: "var(--color-text-primary)",
                  letterSpacing: "1px",
                }}
              >
                {peerId}
              </span>
            </p>
          </div>
        </div>

        <button
          onClick={closeRoom}
          className="glass-button danger"
          style={{ display: "flex", alignItems: "center", gap: "8px" }}
        >
          <Trash2 size={18} />
          Close Room & Shred
        </button>
      </motion.header>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
          gap: "32px",
          flex: 1,
        }}
      >
        <div
          className="glass-card"
          style={{
            padding: "3rem",
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            borderStyle: "dashed",
            borderWidth: "2px",
            borderColor: isDragging
              ? "var(--color-accent-blue)"
              : "var(--color-surface-border)",
            background: isDragging
              ? "rgba(59, 130, 246, 0.05)"
              : "var(--color-surface-1)",
            transition: "all 0.3s ease",
          }}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <UploadCloud
            size={64}
            color={
              isDragging
                ? "var(--color-accent-blue)"
                : "var(--color-text-secondary)"
            }
            style={{ marginBottom: "24px", transition: "all 0.3s ease" }}
          />
          <h3 style={{ fontSize: "1.5rem", marginBottom: "8px" }}>
            Drag & Drop Files Here
          </h3>
          <p
            style={{
              color: "var(--color-text-secondary)",
              marginBottom: "32px",
              textAlign: "center",
            }}
          >
            Direct peer-to-peer transfer.
            <br />
            Max privacy. Instant delivery.
          </p>

          <input
            type="file"
            id="file-upload"
            multiple
            onChange={handleFileInput}
            style={{ display: "none" }}
          />
          <label
            htmlFor="file-upload"
            className="glass-button primary"
            style={{ cursor: "pointer" }}
          >
            Browse Files
          </label>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="glass-card"
          style={{
            padding: "2rem",
            display: "flex",
            flexDirection: "column",
            gap: "32px",
          }}
        >
          <div style={{ flex: 1 }}>
            <h3
              style={{
                fontSize: "1.2rem",
                marginBottom: "16px",
                display: "flex",
                alignItems: "center",
                gap: "8px",
              }}
            >
              <Download size={20} className="text-gradient" /> Received Files
            </h3>
            {receivedFiles.length === 0 ? (
              <p
                style={{
                  color: "var(--color-text-secondary)",
                  fontSize: "0.9rem",
                  fontStyle: "italic",
                }}
              >
                No files received yet. Waiting for peer...
              </p>
            ) : (
              <motion.div
                initial="hidden"
                animate="visible"
                variants={{
                  hidden: { opacity: 0 },
                  visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
                }}
                style={{
                  display: "flex",
                  flexDirection: "column",
                  gap: "12px",
                }}
              >
                <AnimatePresence>
                  {receivedFiles.map((file, i) => (
                    <motion.div
                      key={i}
                      variants={{
                        hidden: { opacity: 0, x: 20 },
                        visible: { opacity: 1, x: 0 },
                      }}
                      exit={{
                        opacity: 0,
                        x: -20,
                        transition: { duration: 0.2 },
                      }}
                      className="glass-panel"
                      style={{
                        padding: "16px",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        borderRadius: "12px",
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "12px",
                          overflow: "hidden",
                        }}
                      >
                        <File
                          size={24}
                          className="text-gradient-accent"
                          style={{ flexShrink: 0 }}
                        />
                        <div style={{ overflow: "hidden" }}>
                          <p
                            style={{
                              margin: 0,
                              fontWeight: 500,
                              whiteSpace: "nowrap",
                              overflow: "hidden",
                              textOverflow: "ellipsis",
                            }}
                          >
                            {file.name}
                          </p>
                          <p
                            style={{
                              margin: 0,
                              fontSize: "0.8rem",
                              color: "var(--color-text-secondary)",
                            }}
                          >
                            {formatSize(file.size)}
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() => downloadFile(file)}
                        className="glass-button primary"
                        style={{ padding: "8px" }}
                      >
                        <Download size={16} />
                      </button>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </motion.div>
            )}
          </div>

          <div style={{ flex: 1 }}>
            <h3
              style={{
                fontSize: "1.2rem",
                marginBottom: "16px",
                display: "flex",
                alignItems: "center",
                gap: "8px",
              }}
            >
              <UploadCloud size={20} className="text-gradient" /> Sent Files
            </h3>
            {sentFiles.length === 0 ? (
              <p
                style={{
                  color: "var(--color-text-secondary)",
                  fontSize: "0.9rem",
                  fontStyle: "italic",
                }}
              >
                You haven't sent any files yet.
              </p>
            ) : (
              <motion.div
                initial="hidden"
                animate="visible"
                variants={{
                  hidden: { opacity: 0 },
                  visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
                }}
                style={{
                  display: "flex",
                  flexDirection: "column",
                  gap: "12px",
                }}
              >
                <AnimatePresence>
                  {sentFiles.map((file, i) => (
                    <motion.div
                      key={i}
                      variants={{
                        hidden: { opacity: 0, x: -20 },
                        visible: { opacity: 1, x: 0 },
                      }}
                      exit={{
                        opacity: 0,
                        x: -20,
                        transition: { duration: 0.2 },
                      }}
                      className="glass-panel"
                      style={{
                        padding: "16px",
                        display: "flex",
                        alignItems: "center",
                        gap: "12px",
                        borderRadius: "12px",
                      }}
                    >
                      <File
                        size={24}
                        color="var(--color-text-secondary)"
                        style={{ flexShrink: 0 }}
                      />
                      <div style={{ overflow: "hidden" }}>
                        <p
                          style={{
                            margin: 0,
                            fontWeight: 500,
                            whiteSpace: "nowrap",
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                          }}
                        >
                          {file.name}
                        </p>
                        <p
                          style={{
                            margin: 0,
                            fontSize: "0.8rem",
                            color: "var(--color-text-secondary)",
                          }}
                        >
                          {formatSize(file.size)} • Sent
                        </p>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </motion.div>
            )}
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
};
