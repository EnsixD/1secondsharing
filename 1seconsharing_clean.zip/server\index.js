const express = require("express");
const { Server } = require("socket.io");
const http = require("http");
const cors = require("cors");

const app = express();
app.use(cors());

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*", // allow all traffic for this demo
    methods: ["GET", "POST"],
  },
  maxHttpBufferSize: 1e8, // Allow 100MB chunk envelopes if needed
});

// Room state: tracking who is in what room to handle disconnects cleanly
const rooms = new Map();

io.on("connection", (socket) => {
  console.log(`[+] Socket connected: ${socket.id}`);

  socket.on("create-room", (roomId) => {
    socket.join(roomId);
    rooms.set(roomId, [socket.id]);
    console.log(`[Room] ${socket.id} created room ${roomId}`);
    socket.emit("room-created", roomId);
  });

  socket.on("join-room", (roomId) => {
    const clients = io.sockets.adapter.rooms.get(roomId);
    if (clients && clients.size === 1) {
      socket.join(roomId);
      rooms.set(roomId, [...(rooms.get(roomId) || []), socket.id]);

      console.log(`[Room] ${socket.id} joined room ${roomId}`);

      // Notify both that connection is ready
      io.to(roomId).emit("peer-connected");
    } else {
      socket.emit("error", "Room is full or does not exist");
    }
  });

  // Relay file chunks directly to other members in the room
  // We don't save anything to disk. We just forward the buffer.
  socket.on("file-chunk", ({ roomId, file }) => {
    // Send to everyone in room EXCEPT sender
    socket.to(roomId).emit("file-received", file);
  });

  socket.on("close-room", (roomId) => {
    console.log(`[Room] ${roomId} closed by ${socket.id}`);
    socket.to(roomId).emit("peer-disconnected");
    io.in(roomId).socketsLeave(roomId);
    rooms.delete(roomId);
  });

  socket.on("disconnect", () => {
    console.log(`[-] Socket disconnected: ${socket.id}`);
    // If they were in a room, notify the other person
    for (const [roomId, members] of rooms.entries()) {
      if (members.includes(socket.id)) {
        console.log(`[Room] Broadcasting disconnect to room ${roomId}`);
        socket.to(roomId).emit("peer-disconnected");
        rooms.delete(roomId); // Room is effectively dead if one leaves
      }
    }
  });
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`\n================================`);
  console.log(`🚀 1SecondSharing Socket.IO Server`);
  console.log(`📡 Listening on port ${PORT}`);
  console.log(`================================\n`);
});
