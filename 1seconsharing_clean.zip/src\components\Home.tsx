import React from "react";
import { motion } from "framer-motion";
import { Zap, Shield, Lock, ArrowRight } from "lucide-react";

interface HomeProps {
  onCreateRoom: () => void;
  onJoinRoom: () => void;
}

export const Home: React.FC<HomeProps> = ({ onCreateRoom, onJoinRoom }) => {
  return (
    <>
      <div
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background:
            "linear-gradient(to bottom, rgba(5,5,5,0) 0%, rgba(10,10,15,1) 100%)",
          zIndex: -1,
          pointerEvents: "none",
        }}
      />
      <div className="animated-grid" />
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{
          opacity: 0,
          filter: "blur(10px)",
          transition: { duration: 0.3 },
        }}
        className="home-container"
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          minHeight: "100vh",
          padding: "2rem",
          textAlign: "center",
        }}
      >
        <motion.div
          initial={{ scale: 0.8, opacity: 0, y: -20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          transition={{
            delay: 0.1,
            duration: 0.8,
            type: "spring",
            stiffness: 100,
          }}
        >
          <div
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "8px",
              padding: "6px 12px",
              background: "var(--color-surface-2)",
              borderRadius: "20px",
              border: "1px solid var(--color-surface-border)",
              marginBottom: "24px",
            }}
          >
            <div
              style={{
                width: "8px",
                height: "8px",
                borderRadius: "50%",
                background: "var(--color-success)",
                boxShadow: "0 0 10px var(--color-success)",
              }}
            />
            <span
              style={{
                fontSize: "0.85rem",
                fontWeight: 500,
                letterSpacing: "0.5px",
              }}
            >
              MILITARY-GRADE P2P FILE SHARING
            </span>
          </div>
        </motion.div>

        <motion.h1
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          style={{
            fontSize: "clamp(3rem, 8vw, 5rem)",
            letterSpacing: "-0.03em",
            marginBottom: "16px",
          }}
        >
          Share files with{" "}
          <span className="text-gradient-accent">Zero Friction.</span>
        </motion.h1>

        <motion.p
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          style={{
            fontSize: "clamp(1.1rem, 2vw, 1.3rem)",
            maxWidth: "600px",
            marginBottom: "48px",
            opacity: 0.8,
          }}
        >
          Direct peer-to-peer connection. Your files are never stored on any
          central server. End-to-end encrypted, instantaneous transfers for
          high-end agencies.
        </motion.p>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          style={{
            display: "flex",
            gap: "20px",
            flexWrap: "wrap",
            justifyContent: "center",
          }}
        >
          <button
            onClick={onCreateRoom}
            className="glass-button primary"
            style={{ padding: "16px 32px", fontSize: "1.1rem" }}
          >
            <Zap size={20} />
            <span>Create Secure Room</span>
          </button>
          <button
            onClick={onJoinRoom}
            className="glass-button"
            style={{ padding: "16px 32px", fontSize: "1.1rem" }}
          >
            <span>Join Existing Room</span>
            <ArrowRight size={20} />
          </button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          style={{
            display: "flex",
            gap: "32px",
            marginTop: "80px",
            flexWrap: "wrap",
            justifyContent: "center",
          }}
        >
          <motion.div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "12px",
              animation: "float 6s ease-in-out infinite",
            }}
            whileHover={{ scale: 1.05 }}
          >
            <div
              style={{
                padding: "12px",
                background: "rgba(255,255,255,0.03)",
                borderRadius: "16px",
                border: "1px solid rgba(255,255,255,0.1)",
              }}
            >
              <Shield className="text-gradient" size={28} />
            </div>
            <div style={{ textAlign: "left" }}>
              <h3
                style={{
                  fontSize: "1.1rem",
                  fontWeight: 600,
                  marginBottom: "4px",
                }}
              >
                End-to-End Encrypted
              </h3>
              <p style={{ fontSize: "0.85rem", margin: 0, opacity: 0.7 }}>
                Military socket relay standard
              </p>
            </div>
          </motion.div>

          <motion.div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "12px",
              animation: "float 6s ease-in-out infinite 3s",
            }}
            whileHover={{ scale: 1.05 }}
          >
            <div
              style={{
                padding: "12px",
                background: "rgba(255,255,255,0.03)",
                borderRadius: "16px",
                border: "1px solid rgba(255,255,255,0.1)",
              }}
            >
              <Lock className="text-gradient" size={28} />
            </div>
            <div style={{ textAlign: "left" }}>
              <h3
                style={{
                  fontSize: "1.1rem",
                  fontWeight: 600,
                  marginBottom: "4px",
                }}
              >
                Zero Storage
              </h3>
              <p style={{ fontSize: "0.85rem", margin: 0, opacity: 0.7 }}>
                100% ephemeral memory
              </p>
            </div>
          </motion.div>
        </motion.div>
      </motion.div>
    </>
  );
};
