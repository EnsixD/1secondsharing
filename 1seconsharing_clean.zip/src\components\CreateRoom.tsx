import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  ShieldAlert,
  Copy,
  CheckCircle2,
  ArrowLeft,
  Loader2,
} from "lucide-react";
import type { ConnectionState } from "../hooks/useSocketSharing";

interface CreateRoomProps {
  onBack: () => void;
  initPeer: () => string;
  peerId: string;
  status: ConnectionState;
  errorText: string;
}

export const CreateRoom: React.FC<CreateRoomProps> = ({
  onBack,
  initPeer,
  peerId,
  status,
  errorText,
}) => {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    // Generate code and init peer connection on mount
    initPeer();
  }, [initPeer]);

  const copyToClipboard = () => {
    if (peerId) {
      navigator.clipboard.writeText(peerId);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 50 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -50 }}
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        minHeight: "100vh",
        padding: "2rem",
      }}
    >
      <button
        onClick={onBack}
        style={{
          position: "absolute",
          top: "2rem",
          left: "2rem",
          background: "transparent",
          border: "none",
          color: "var(--color-text-secondary)",
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          gap: "8px",
        }}
      >
        <ArrowLeft size={20} /> Back
      </button>

      <div
        className="glass-card"
        style={{
          padding: "3rem",
          maxWidth: "500px",
          width: "100%",
          textAlign: "center",
        }}
      >
        <ShieldAlert
          className="text-gradient"
          size={48}
          style={{ margin: "0 auto 24px auto" }}
        />
        <h2 style={{ fontSize: "2rem", marginBottom: "8px" }}>
          Secure Room Created
        </h2>
        <p style={{ marginBottom: "32px" }}>
          Share this unique code with your recipient. The room will close when
          you leave.
        </p>

        {status === "connecting" && !peerId && (
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              padding: "2rem",
            }}
          >
            <Loader2
              className="lucide-spin text-gradient-accent"
              size={32}
              style={{ animation: "spin 2s linear infinite" }}
            />
          </div>
        )}

        {errorText && (
          <div
            style={{
              padding: "16px",
              background: "var(--color-danger-glow)",
              border: "1px solid var(--color-danger)",
              borderRadius: "12px",
              color: "var(--color-danger)",
              marginBottom: "24px",
            }}
          >
            {errorText}
          </div>
        )}

        {peerId && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            style={{ marginBottom: "32px" }}
          >
            <div
              onClick={copyToClipboard}
              className="glass-panel-interactive"
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "20px",
                fontSize: "2rem",
                fontWeight: 600,
                letterSpacing: "4px",
              }}
            >
              <span className="text-gradient-accent">{peerId}</span>
              {copied ? (
                <CheckCircle2 color="var(--color-success)" />
              ) : (
                <Copy color="var(--color-text-secondary)" />
              )}
            </div>
          </motion.div>
        )}

        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: "12px",
            color: "var(--color-text-secondary)",
          }}
        >
          {status === "disconnected" && peerId ? (
            <>
              <Loader2
                size={16}
                style={{ animation: "spin 2s linear infinite" }}
              />
              <span style={{ fontSize: "0.9rem" }}>
                Waiting for connection...
              </span>
            </>
          ) : status === "connected" ? (
            <span style={{ fontSize: "0.9rem", color: "var(--color-success)" }}>
              Peer Connected!
            </span>
          ) : null}
        </div>
      </div>
      <style>{`@keyframes spin { 100% { transform: rotate(360deg); } }`}</style>
    </motion.div>
  );
};
